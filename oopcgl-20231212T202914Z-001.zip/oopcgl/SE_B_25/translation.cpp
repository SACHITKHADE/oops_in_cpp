#include <iostream>
#include <graphics.h>

int main(){
   
    int coordinate_matrix[3][3] = {{442,200,1},
                                   {500,100,1}, 
                                   {558,200,1}};
                                                                 
    int translation_matrix[3][3] = {{1,0,0},
                                    {0,1,0}, 
                                    {-300,200,1}};

    int result_matrix[3][3];
    
    
    //Shape before translation
    initgraph(&gd, &gm, NULL);
    line(320,0,320,480);
    line(0,240,640,240);
    line(442,200,558,200);
    line(500,100,442,200);
    line(500,100,558,200);
    delay(3000);
    
    
    //matrix multiplication
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            result_matrix[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                result_matrix[i][j] += coordinate_matrix[i][k] * translation_matrix[k][j];
            }
        }
    }
    
    
    //Translated polygon
    line(result_matrix[0][0],result_matrix[0][1], result_matrix[1][0],result_matrix[1][1]);
    line(result_matrix[0][0],result_matrix[0][1], result_matrix[2][0],result_matrix[2][1]);
    line(result_matrix[2][0],result_matrix[2][1], result_matrix[1][0],result_matrix[1][1]);
    
    
    return 0;
}

