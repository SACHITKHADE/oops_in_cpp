#include <iostream>
#include <graphics.h>

using namespace std;

int main(){
    int gd = DETECT;
    int gm;
    //int coordinate_matrix[3][3] = {{442,200,1},
    //                               {500,100,1}, 
    //                              {558,200,1}};
    
    int coordinate_matrix[3][3] = {{,200,1},
                                   {500,100,1}, 
                                    {558,200,1}};
                                   
    float scaling_matrix[3][3] = {{2,0,0},
                                {0,1,0}, 
                                {0,0,1}};

    int result_matrix[3][3];
    
    
    //Shape before scaling
    initgraph(&gd, &gm, NULL);
    line(320,0,320,480);
    line(0,240,640,240);
    line(442,200,558,200);
    line(500,100,442,200);
    line(500,100,558,200);
    delay(3000);
    
    
    //matrix multiplication
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            result_matrix[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                result_matrix[i][j] += coordinate_matrix[i][k] * scaling_matrix[k][j];
            }
        }
    }
    
    
    //scaled polygon
    line(result_matrix[0][0],result_matrix[1][0], result_matrix[0][1],result_matrix[1][1]);
    line(result_matrix[0][1],result_matrix[1][1], result_matrix[0][2],result_matrix[1][2]);
    line(result_matrix[0][2],result_matrix[1][2], result_matrix[0][0],result_matrix[1][0]);
    delay(5000);
    
    return 0;
}
