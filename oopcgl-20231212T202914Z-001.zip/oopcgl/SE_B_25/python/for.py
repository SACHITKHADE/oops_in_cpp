#For loop for a pattern

for i range(1,10):
    print("#"*i)
    
    
