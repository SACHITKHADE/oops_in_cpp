#include <iostream>
#include <string.h>

using namespace std;

class Student{
    char name[20], blood_group[4], date_of_birth[10], division[2];
    int age, contact, roll_no, year;
    
    static int count;                          //static variable
    
    public:
        void getData();
        void displayData();    
        friend void displayData(Student &obj);
    
    Student(){                                 //Constructor         
        roll_no = 0;
        cout<<"Constructor\n";
        roll_no = count;
        count++;
    }
         
    ~Student(){
        cout<<"\nDestructor destroying the object";              //Destructor
        cout<<"\n Destroying the object";    
        count++; 
    }
        
    static void getCount(){				// Static member function (only access static members))
        cout<<"Constructor count is: "<<count<<endl;
    }                       
    
    Student(Student &obj){				//copy constructor
        roll_no = obj.roll_no;
        contact = obj.contact;
        year = obj.year;
        age = obj.age;
        strcpy(name, obj.name);
        strcpy(blood_group, obj.blood_group);
        strcpy(date_of_birth, obj.date_of_birth);
        strcpy(division, obj.division);
        count++;
    }
};


int Student::count=0;	   //static varriable default declaration


void Student::getData(){
    cout<<"Enter the student details as follows: \n";
    cout<<"Enter name: ";
    cin>>name;
    cout<<"Enter Roll no: ";
    cin>>roll_no;
    cout<<"Enter division: ";
    cin>>division;
    cout<<"Enter Year of studying: ";
    cin>>year;
    cout<<"Enter Date of birth: ";
    cin>>date_of_birth;
    cout<<"Enter age: ";
    cin>>age;
    cout<<"Enter Blood Group";
    cin>>blood_group;
    cout<<"Enter contact: ";
    cin>>contact;
}


void displayData(Student &obj){  //friend function
    cout<<"\n"<<obj.roll_no;
    cout<<"\t"<<obj.name;
    cout<<"\t "<<obj.date_of_birth;
    cout<<"\t"<<obj.blood_group;
    cout<<"\t "<<obj.division;
    cout<<"\t"<<obj.year;
    cout<<"\t"<<obj.contact<<endl;
}


int main(){
    Student s1;
    
    Student s2(s1);	//copy constructor
 
    Student:: getCount(); //accessing static function


    Student *s[50]; //array of objects
    int i,n;
    cout<<"\nHow many student objects do you want to create?";
    cin>>n;

    for(i=0;i<n;i++){
        s[i]=new Student();  //dynamic memory allocation operator
        }
        
    for(i=0;i<n;i++){
        s[i]-> getData();
 	}
 	
    cout<<"\nAll the details are as below:\n";
    cout<<"ROLL \t NAME \t DOB \t BLOODGRP \t CLASS \t DIV\t PHONE \n";
     	
    for(i=0;i<n;i++){
	displayData(*s[i]);
 	}
 	
    Student:: getCount(); //accessing static function
    
    for(i=0;i<n;i++){
	delete (s[i]);  //dynamic memory de-allocation operator
	}
	
	
    return 0;
}
