#include <iostream>
#include <graphics.h>

int main(){
    int gd = DETECT;
    int gm, i= 600, j=0;
    initgraph(&gd, &gm, NULL);
    while(i>4){
        circle(i,i+50,i);
        i=i-5;
    delay(10000);
    closegraph();
    return 0;
}
