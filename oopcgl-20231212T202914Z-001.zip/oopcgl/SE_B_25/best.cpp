//Program for pattern1 

/*#include <iostream>
#include <graphics.h>

int main(){
    int gd = DETECT;
    int gm;
    initgraph(&gd, &gm, NULL);
    rectangle(100,100,400,300);
    line(250,100,100,200);
    line(100,200,250,300);
    line(250,300,400,200);
    line(400,200,250,100);
    circle(250,200,82);
    delay(10000);
    closegraph();
    return 0;
}
*/


//program for pattern2

#include <iostream>
#include <graphics.h>

int main(){
    int gd = DETECT;
    int gm;
    initgraph(&gd, &gm, NULL);
    line(300,100,300,200);
    line(242,200,358,200);
    line(300,100,242,200);
    line(300,100,358,200);
    circle(300,165,67);
    circle(300,165,33);
    delay(10000);
    closegraph();
    return 0;
}



