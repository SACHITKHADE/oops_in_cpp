#include <iostream>

using namespace std;

class Publication{
    protected:
        char title[20];
        float price;
    public:
        void getDetails(){
            cout<<"Enter title of the publication: ";
            cin>>title;
            cout<<"Enter price of the publication: ";
            cin>>price;
        }
        
        void displayDetails(){
            cout<<"Title of the publication:"<<title;
            cout<<"Price of the publication: "<<price;
        }
};


class Book:public Publication{
     int page_count;
     
     public:
         void getDetails(){
             Publication::getDetails();
             cout<<"Enter number of pages of book";
             cin>>page_count;
         }
         
         void displayDetails(){
            Publication::displayDetails();
            cout<<"Title of the publication: \n"<<title;
            cout<<"Price of the publication: \n"<<price;
            cout<<"Number of pages of book: \n"<<page_count;
         }
};


class Tape:public Publication{
    float runtime;
    
    public:
        void getDetails(){
            Publication::getDetails();
            cout<<"Enter runtime of the tape: \n";
            cin>>runtime;
        } 
    
        void displayDetails(){
            Publication::displayDetails();
            cout<<"Runtime of the tape is: \n"<<runtime;
        }
};

int main(){
    Publication p1;
    Book b1;
    Tape t1;
    t1.getDetails();
    t1.displayDetails();   
}
