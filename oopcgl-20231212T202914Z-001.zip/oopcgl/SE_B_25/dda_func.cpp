#include <iostream>

void dda_line_algo(int x1, int y1, int x2, int y2){
    
    int i, x, y, length, Dx, Dy;
    int gd = DETECT;
    int gm;
    initgraph(&gd, &gm, NULL);
    
    if(abs(x2-x1)>=abs(y2-y1)){
        length = abs(x2-x1);
    }
    
    else{
        length = abs(y2-y1);
    }
    
    Dx = (x2-x1)/length;
    Dy = (y2-y1)/length;
    
    x = x1+0.5;
    y = y1+0.5;
    
    i=1;
    while(i<=length){
        putpixel(int(x), int(y), 15);
        x = x + Dx;
        y = y + Dy;
        i = i+1;
    }
    
    delay(10000);
    closegraph();
    return 0;
}

int main(){
    int side;
    
    cout<<"Enter length of side of the triangle";
    cin>>side;
    
    
    
}
